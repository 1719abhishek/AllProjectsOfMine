package com.example.SpringCloudGatewayService2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudGatewayService2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudGatewayService2Application.class, args);
	}

}
