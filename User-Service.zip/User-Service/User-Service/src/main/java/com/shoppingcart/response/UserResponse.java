package com.shoppingcart.response;

import java.util.Date;

public class UserResponse {
	
	 private long userid;
	 private String username;
	 private String lastname;
	 private String email;
	 private Date createdat;
	 private Date updatedat;
	 
	    public long getUserid() {
			return userid;
		}
		public void setUserid(long userid) {
			this.userid = userid;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getLastname() {
			return lastname;
		}
		public void setLastname(String lastname) {
			this.lastname = lastname;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public Date getCreatedat() {
			return createdat;
		}
		public void setCreatedat(Date createdat) {
			this.createdat = createdat;
		}
		public Date getUpdatedat() {
			return updatedat;
		}
		public void setUpdatedat(Date updatedat) {
			this.updatedat = updatedat;
		}
 }
