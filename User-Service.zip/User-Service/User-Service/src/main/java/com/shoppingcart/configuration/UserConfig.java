package com.shoppingcart.configuration;

public class UserConfig {

}
