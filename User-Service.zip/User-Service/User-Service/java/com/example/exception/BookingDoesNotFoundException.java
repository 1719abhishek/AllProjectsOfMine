package com.example.exception;

public class BookingDoesNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BookingDoesNotFoundException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public BookingDoesNotFoundException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
}
