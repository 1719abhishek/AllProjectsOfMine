package com.example.exception;

public class NullAdminException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NullAdminException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public NullAdminException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	
	
}
