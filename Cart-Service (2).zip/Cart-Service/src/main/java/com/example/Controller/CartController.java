package com.example.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.Service.CartService;
import com.example.entity.Cart;
import jakarta.transaction.Transactional;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@Transactional
@RequestMapping("/cart")
public class CartController {
	@Autowired
	private CartService cartService;

	@GetMapping("/getCartDetails")
	public ResponseEntity<List<Cart>> getAllCarts() {
		List<Cart> carts = cartService.getAllCarts();
		return ResponseEntity.ok(carts);
	}

	@PostMapping("/add")
	public ResponseEntity<Cart> addToCart(@RequestBody Cart cart) {

		Cart addedCart = cartService.addToCart(cart);
		return ResponseEntity.ok(addedCart);

	}
	@PostMapping("/add-by-id/{productId}")
    public ResponseEntity<Cart> addToCartById( @PathVariable Long productId) {
      
            Cart addedCart = cartService.addToCartById(productId);
            return ResponseEntity.ok(addedCart);
	}
	@DeleteMapping("/delete/{cartId}")
	public ResponseEntity<Void> deleteCart(@PathVariable Long cartId) {

		cartService.deleteCart(cartId);
		return ResponseEntity.noContent().build();
	}
	@GetMapping("/getcart/{cartId}")
    public Optional<Cart> getProductById(@PathVariable Long cartId) {
        return cartService.getCartById(cartId);
    }
	@PutMapping("/update-cart/{cartId}/{orderStatus}")
    public ResponseEntity<Void> updateCartStatus(@PathVariable Long cartId, @PathVariable String orderStatus) {
        cartService.UpdateCart(cartId, orderStatus);
        return ResponseEntity.noContent().build();
    }
}
