package com.example.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.entity.Cart;

import jakarta.transaction.Transactional;
//@Transactional
@Repository
public interface CartRepository extends JpaRepository<Cart,Long> {
//	@Modifying(flushAutomatically = true)
//	 @Query("UPDATE cart c SET c.order_status = :status WHERE c.cartid = :cartId")
//	    public void updateCartStatus(@Param("cartId") Long cartId,@Param("status") String status);
 
}
