package com.example.Service;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import com.example.Repository.CartRepository;
import com.example.Repository.ProductRepository;
import com.example.entity.Cart;
import com.example.entity.ProductEntity;

@Service
public class CartService {

	@Autowired
	private CartRepository repository;
	@Autowired
	private RestTemplate restTemplate;
	
	

	private static final String url = "http://localhost:8087/product/getproduct/";

	public Cart addToCart(Cart cart) {

		ProductEntity product = getProductDetails(cart.getProductId());
		cart.setCreatedAt(new Date());
		cart.setProduct(product);

		return  repository.save(cart);

	}
	public Cart addToCartById(Long productId) {
		ProductEntity product = getProductDetails(productId);

		Cart cart = new Cart();

		cart.setProductId(productId);
		cart.setProduct(product); 
		cart.setCreatedAt(new Date());

		return repository.save(cart);
	}
	public List<Cart> getAllCarts() {
		List<Cart> allCarts = repository.findAll();
		List<Cart> filteredCarts = allCarts.stream()
				.filter(cart -> !"Y".equals(cart.getOrder_status()))
				.collect(Collectors.toList());
		return filteredCarts;
	}
	public void deleteCart(Long cartId) {
		repository.deleteById(cartId);
	}
//	public void UpdateCart(Long cartId) {
//		repository.updateCartStatus(cartId,"Y");
//		
//	}

	
	private ProductEntity getProductDetails(Long productId) {
		
		String productApiUrl = url + productId;
		ResponseEntity<ProductEntity> responseEntity = restTemplate.getForEntity(productApiUrl, ProductEntity.class);

		if (responseEntity.getStatusCode() == HttpStatus.OK) {
			return responseEntity.getBody();
		} else {
			throw new RestClientException("Failed to get product details. Status code: " + responseEntity.getStatusCode());
		}
	}
	
	public Optional<Cart> getCartById(Long cartId)
	{
		return repository.findById(cartId);
	}
	 public void UpdateCart(Long cartId, String orderStatus) {
	        Optional<Cart> optionalCart = repository.findById(cartId);

	        if (optionalCart.isPresent()) {
	            Cart cart = optionalCart.get();
	            cart.setOrder_status(orderStatus);
	            repository.save(cart);
	        } else {
	            throw new RuntimeException("Cart with ID " + cartId + " not found");
	        }
	    }

}
