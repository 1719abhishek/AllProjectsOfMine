package com.example.OrderService.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.OrderService.orderEntity.Order;

public interface OrderRepository  extends JpaRepository<Order,Long>{

}
