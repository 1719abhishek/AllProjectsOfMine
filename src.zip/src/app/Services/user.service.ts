import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }
  login(data:any)
  {
    return this.http.post<any>("http://localhost:8086/user/userLogin",data)
  }
  postsignup(data:any)
  {
    return this.http.post<any>("http://localhost:8086/user/addUser",data)
  }
  addproduct(data:any)
  {
    return this.http.post<any>("http://localhost:8087/product/add-product",data)
  }
  getproduct()
  {
    return this.http.get("http://localhost:8087/product/getall-products")
  }
  deleteProduct(id: number): Observable<any> {
    return this.http.delete(`http://localhost:8087/product/delete-product/${id}`);
  }
  updateProduct(id: number, data: any): Observable<any> {
    return this.http.put(`http://localhost:8087/product/update-product/${id}`, data);
  }
  // addcart(id:any)
  // {
  //   return this.http.get(`http://localhost:8088/add-by-id/${id}`);
  // }
  addToCartById(productId: number): Observable<any> {
    const url = `http://localhost:8088/cart/add-by-id/${productId}`;
    // You can adjust the payload structure based on your server's expectations
    const payload = {
      productId: productId,
    };

    return this.http.post<any>(url, payload);
  }
  deleteCart(id: number): Observable<any> {
    return this.http.delete(`http://localhost:8088/cart/delete/${id}`);
  }
  public getCartDetails() {
    return this.http.get("http://localhost:8088/cart/getCartDetails");
  }
  private baseUrl = 'http://localhost:8089/order'; 
  placeOrder(userId: number, cartId: number): Observable<any> {
    const url = `${this.baseUrl}/place/${userId}/${cartId}`;
    return this.http.post<any>(url, null);
  }
  public getOrderDetails() {
    return this.http.get("http://localhost:8089/order/getOrderDetails");
  }
  
  deleteOrder(id: number): Observable<any> {
    return this.http.delete(`http://localhost:8089/order/delete/${id}`);
  }
  

 
}
