import { Component, OnInit } from '@angular/core';
import { UserService } from '../Services/user.service';
import { Router } from '@angular/router';
import { CoreService } from '../Services/core.service';
export interface ProductData {
  cartId: number;
  createdAt: Date;
  product: {
    productName: string;
    productDescription: string;
    
    updatedAt: Date;
  };
}


@Component({
  selector: 'app-view-cart',
  templateUrl: './view-cart.component.html',
  styleUrl: './view-cart.component.css'
})

export class ViewCartComponent implements OnInit {
  cartDetails: any[] = [];
  displayedColumns: string[] = ['Name', 'Description', 'createdAt', 'Action','Cart Id'];
  userId: number=2;
   
  // product!: ProductData

  constructor(private productService: UserService,
    private router: Router,private _coreService:CoreService) { }

  ngOnInit(): void {
    this.getCartDetails();
  }

  delete(id:any) {
    console.log(id);
    this.productService.deleteCart(id).subscribe(
      (resp) => {
        console.log(resp);
        this._coreService.openSnackBar('Cart deleted!', 'done');
        this.getCartDetails();
      }, (err) => {
        console.log(err);
      }
    );
  }

  getCartDetails() {
    this.productService.getCartDetails().subscribe(
      (response:any) => {
        console.log(response);
        this.cartDetails = response;
      },
      (error) => {
        console.log(error);
      }
    );
  }
  placeOrder(cartId: number) {
    this.productService.placeOrder(this.userId, cartId).subscribe(
      (resp) => {
        console.log(resp);
        this._coreService.openSnackBar('Order placed successfully!', 'done');
        // Optionally, you can navigate the user to a confirmation page or do other actions
        // this.router.navigate(['/order-confirmation']);
      },
      (err) => {
        console.log(err);
        this._coreService.openSnackBar('Failed to place order. Please try again.', 'error');
      }
    );
  }
  placeOrderForAll() {
    const userConfirmed = window.confirm('Are you sure you want to place orders for all items?');
    if (userConfirmed) {
      for (const element of this.cartDetails) {
        this.placeOrder(element.cartId);
        // Optionally, you may want to remove the product from the cart after placing the order
        //this.delete(element.cartId);
      }
    }
  }
}
