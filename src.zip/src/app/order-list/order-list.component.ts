import { Component, OnInit } from '@angular/core';
import { UserService } from '../Services/user.service';
import { CoreService } from '../Services/core.service';
import { Router } from '@angular/router';
export interface ProductData {
  cartId: number;
  orderId: number;
  createdAt: Date;
}

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.component.html',
  styleUrl: './order-list.component.css'
})
export class OrderListComponent  implements OnInit {
  orderDetails: any[] = [];
  displayedColumns: string[] = ['CartId', 'OrderId', 'createdAt', 'Action'];

   
  // product!: ProductData

  constructor(private OrderService: UserService,
    private router: Router,private _coreService:CoreService) { }

  ngOnInit(): void {
    this.getOrderDetails();
  }
  getOrderDetails() {
    this.OrderService.getOrderDetails().subscribe(
      (response:any) => {
        console.log(response);
        this.orderDetails = response;
      },
      (error) => {
        console.log(error);
      }
    );
  }
  delete(id:any) {
    console.log(id);
    this.OrderService.deleteOrder(id).subscribe(
      (resp) => {
        console.log(resp);
        this._coreService.openSnackBar('Order deleted!', 'done');
        this.getOrderDetails();
      }, (err) => {
        console.log(err);
      }
    );
  }
  deleteOrderForAll() {
    const userConfirmed = window.confirm('Are you sure you want to Cancel orders for all items?');
    if (userConfirmed) {
      for (const element of this.orderDetails) {
        this.delete(element.orderId);
        
      }
    }
  }
  logout(){
    localStorage.removeItem("userId");
    this.router.navigate(["/login"]);
  }

}
