package com.javatpoint.microservices.currencyconversionservicce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurrencyConversionServicceApplicationTests {

	@Test
	void contextLoads() {
	}

}
