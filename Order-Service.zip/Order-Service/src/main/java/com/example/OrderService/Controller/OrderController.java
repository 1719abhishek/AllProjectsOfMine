package com.example.OrderService.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.OrderService.Service.OrderService;
import com.example.OrderService.orderEntity.Order;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/order")
public class OrderController {
	@Autowired
    private OrderService orderService;

    @PostMapping("/place/{userid}/{cartId}")
    public ResponseEntity<?> placeOrder(@PathVariable Long userid, @PathVariable Long cartId) {
        Order order = orderService.placeOrder(userid, cartId);
        if (order != null) {
        	return ResponseEntity.ok().body(order);
        } else {
        	 return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Failed to place order. Please check user and cart information.");
        }
    }
    @GetMapping("/getOrderDetails")
	public ResponseEntity<List<Order>> getAllCarts() {
		List<Order> carts = orderService.getAllCarts();
		return ResponseEntity.ok(carts);
	}
    @DeleteMapping("/delete/{orderId}")
	public ResponseEntity<Void> deleteCart(@PathVariable Long orderId) {

    	orderService.deleteCart(orderId);
		return ResponseEntity.noContent().build();
	}

}
