package com.example.OrderService.Service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.OrderService.Repository.OrderRepository;
import com.example.OrderService.orderEntity.Cart;
import com.example.OrderService.orderEntity.Order;
import com.example.OrderService.orderEntity.User;

@Service
public class OrderService {
	private static final String USER_SERVICE_URL = "http://localhost:8086/user/getuser/{userId}";
    private static final String CART_SERVICE_URL = "http://localhost:8088/cart/getcart/{cartId}";

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private RestTemplate restTemplate;

    public Order placeOrder(Long userid, Long cartId) {
        User user = restTemplate.getForObject(USER_SERVICE_URL, User.class, userid);
        Cart cart = restTemplate.getForObject(CART_SERVICE_URL, Cart.class, cartId);

        if (user == null || cart == null) {
            // Handle invalid user or cart
            return null;
        }

        // Create a new Order
        Order order = new Order();
        order.setUserId(userid);
        order.setCartId(cartId);
        order.setCreatedAt(new Date());
        order.setCart(cart); // Set the cart details
        order.setUser(user);
        
        return orderRepository.save(order);
    }
    public List<Order> getAllCarts() {
		return orderRepository.findAll();
	}
    public void deleteCart(Long orderId) {
    	orderRepository.deleteById(orderId);
	}

    
}


